const platformClient = require("purecloud-platform-client-v2");
const fs = require("fs");
const { table } = require("console");
require("dotenv").config();
moment = require("moment");

// import fs from "fs";
// import platformClient from "purecloud-platform-client-v2";
// import "dotenv/config";

// require('dotenv').config()

const client = platformClient.ApiClient.instance;
const apiInstance = new platformClient.OutboundApi();

const listResult = [];

function convertToCSV(objArray) {
  const array = typeof objArray != "object" ? JSON.parse(objArray) : objArray;
  let str = "campaignId, campaignName, queueName, contactListId, contactListName, callerAddress, Priority, callresponse, dialingMode, siteName, "+
  "campaignStatus, callerName, divisionName, alwaysRunning, noAnswerTimeout, callAnalysisLanguage, abandonRate, numberlines, dateCreated, dateModified\n";


  for (let i = 0; i < array.length; i++) {
    let line = "";
    for (let index in array[i]) {
      if (line != "") line += ",";

      line += array[i][index];
    }

    str += line + "\r\n";
  }

  return str;
}

async function getCampaign(opts, page = 1) {
  opts.pageNumber = page;

//  const resp = await apiInstance.getRoutingQueues(opts);
  const resp = await apiInstance.getOutboundCampaigns(opts);
  
  

  const result = resp.entities.map((campaign) => {
    return {
      campaignId: campaign?.id ?? "",
      campaignName: campaign?.name ?? "",
      queueName: campaign?.queue?.name ?? "",
      contactListId: campaign?.contactList?.id ?? "",
	    contactListName: campaign?.contactList?.name ?? "",
	    callerAddress: campaign?.callerAddress ?? "",
      priority: campaign?.priority ?? "",
      callResponse: campaign?.callAnalysisResponseSet?.name ??"",      
      dialingMode: campaign?.dialingMode ?? "",
      siteName: campaign?.site?.name ?? "",
      campaignStatus: campaign?.campaignStatus ?? "",
      callerName: campaign?.callerName ?? "",	    
	    divisionName: campaign?.division?.name ?? "",
      alwaysRunning: campaign?.alwaysRunning ?? "",
      noAnswerTimeout: campaign?.noAnswerTimeout ?? "",
      callAnalysisLanguage: campaign?.callAnalysisLanguage ?? "",
      abandonRate: campaign?.abandonRate ?? "",     
      outboundLineCount: campaign?.outboundLineCount ?? "",
      dateCreated: campaign?.dateCreated ?? "",
      dateModified: campaign?.dateModified ?? "",
    };
  });

  listResult.push(...result);
  if (resp.pageCount > opts.pageNumber) {
    const nextPage = page + 1;
    await getCampaign(opts, nextPage);
  }
}

const clientId = process.env.CLIENT_ID;
const clientSecret = process.env.CLIENT_SECRET;
client
  .loginClientCredentialsGrant(clientId, clientSecret)
  .then(() => {
    // Do authenticated things

    const opts = {
      pageSize: 25, // Number | Page number
      pageNumber: 1, // Number | Page size
      // filterType: "Prefix", // String | Note: results are sorted by name.
	  // sortOrder: "a",
      // 'name': "name_example", // String | Filter by queue name
      // 'id': ["id_example"], // [String] | Filter by queue ID(s)
      // 'divisionId': ["divisionId_example"] // [String] | Filter by queue division ID(s)
    };
    getCampaign(opts)
      .then(() => {

        console.table(listResult)
        const rawLine = convertToCSV(listResult);

        const myArgs = process.argv.slice(2);

        let fileName = "campaign";
        if (myArgs.length >=1) {
          fileName = myArgs[0]
        }
		
		//fs.writeFile(`${fileName}.csv`, rawLine, (err) => {
          fs.writeFile(process.env.CUSTOMER + `_campaigns.csv`, rawLine, (err) => {
          if (err) throw err;
          console.log("O arquivo foi salvo com SUCESSO!");
        });
      })
      .catch((err) => {
        console.log(err);
      });
  })
  .catch((err) => {
    console.log(err);
  });
